import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:prueba_arguello_joel/services/firestone_service.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  void sendVerificationCode(
      String phoneNumber, Function(String) onCodeSent) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async {
        await _auth.signInWithCredential(credential);
      },
      verificationFailed: (FirebaseAuthException e) {
        print('Error al enviar el código: ${e.message}');
      },
      codeSent: (String verificationId, int? resendToken) {
        onCodeSent(verificationId);
      },
      codeAutoRetrievalTimeout: (String verificationId) {},
    );
  }

  Future<bool> verifyCode(
      String verificationId, String smsCode, String name) async {
    try {
      // Código para verificar el SMS con el ID de verificación
      // Ejemplo de código para Firebase:
      PhoneAuthCredential credential = PhoneAuthProvider.credential(
        verificationId: verificationId,
        smsCode: smsCode,
      );

      // Intentar iniciar sesión con las credenciales
      UserCredential userCredential =
          await FirebaseAuth.instance.signInWithCredential(credential);

      // Guardar el nombre del usuario en Firestore u otra base de datos si es necesario
      if (userCredential.user != null) {
        // Guardar nombre en Firestore
        await FirebaseFirestore.instance
            .collection('users')
            .doc(userCredential.user!.uid)
            .set({
          'name': name,
          'phoneNumber': userCredential.user!.phoneNumber,
        });

        return true; // Verificación exitosa
      } else {
        return false; // Algo falló
      }
    } catch (e) {
      // Manejar errores
      print(e);
      return false; // Verificación fallida
    }
  }
}
